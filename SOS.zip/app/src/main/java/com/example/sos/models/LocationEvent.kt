package com.example.sos.models

data class LocationEvent(
    val latitude: Double?,
    val longitude: Double?
)
